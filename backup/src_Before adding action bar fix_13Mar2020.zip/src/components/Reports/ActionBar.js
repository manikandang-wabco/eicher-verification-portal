import React, { Component } from "react";
import ReportsCSS from "./Reports.module.css";
import DatetimeRangePicker from "react-bootstrap-datetimerangepicker";
import { Button, ButtonGroup } from "react-bootstrap";

class ActionBar extends Component {
  render() {
    // Date range picker
    let start = this.props.stateVal.startDate.format("YYYY-MM-DD");
    let end = this.props.stateVal.endDate.format("YYYY-MM-DD");
    let label = start + " - " + end;
    if (start === end) {
      label = start;
    }
    return (
      <div className="ActionBar">
        <div className="form-row align-items-center">
          <div className="col-auto my-1">
            <select
              className="custom-select mr-sm-2 input-item"
              id="inlineFormCustomSelect"
              placeholder="Select Vehicle"
              onChange={this.props.handleChange}
              name="selectedVehicle"
              title="Select the vehicle"
            >
              <option>---Select Vehicle---</option>
              {this.props.stateVal.vehicle &&
                this.props.stateVal.vehicle.map((h, i) => (
                  <option key={i} value={h.key}>
                    {h.value}
                  </option>
                ))}
            </select>
            <span className="loadingInput">
              <img
                alt="Loading.."
                className="loading-img"
                src="./images/loading.gif"
              ></img>
            </span>
          </div>

          <div className="col-auto my-1">
            <ButtonGroup aria-label="Basic example">
              <Button
                variant={this.props.stateVal.activeDate}
                value="odo"
                onClick={this.props.searchBy}
                className={this.props.stateVal.activeDate}
              >
                Odo
              </Button>
              <Button
                variant={this.props.stateVal.activeOdo}
                value="date"
                onClick={this.props.searchBy}
                className={this.props.stateVal.activeOdo}
              >
                Date
              </Button>
            </ButtonGroup>
          </div>
          <div className="col-auto my-1">
            <div className={this.props.stateVal.searchByDate}>
              <DatetimeRangePicker
                startDate={this.props.stateVal.startDate}
                endDate={this.props.stateVal.endDate}
                ranges={this.props.stateVal.ranges}
                onEvent={this.handleEvent}
              >
                <input
                  type="text"
                  className={ReportsCSS.dateRangePicker}
                  value={label}
                />
              </DatetimeRangePicker>
            </div>
          </div>
          <div className="col-auto my-1">
            <div className={this.props.stateVal.searchByOdo}>
              <input
                type="text"
                className={ReportsCSS.startOdo}
                placeholder="Start ODO"
                name="startOdo"
                title="Enter the start odo"
                onChange={this.props.handleChange}
                value={this.props.stateVal.startOdo}
              />
              <input
                type="text"
                className={ReportsCSS.endOdo}
                placeholder="End ODO"
                name="endOdo"
                title="Enter the end odo"
                onChange={this.props.handleChange}
                value={this.props.stateVal.endOdo}
              />
            </div>
          </div>
          <div className="col-auto my-1 ">
            <input
              type="text"
              value={this.props.stateVal.speed}
              name="speed"
              title="Enter the speed"
              className={ReportsCSS.speedInput}
              onChange={this.props.handleChange}
            />
          </div>
          <div className="col-auto my-1 ">
            <button
              onClick={this.props.fetchData}
              className="btn btn-primary btn-custom"
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default ActionBar;
